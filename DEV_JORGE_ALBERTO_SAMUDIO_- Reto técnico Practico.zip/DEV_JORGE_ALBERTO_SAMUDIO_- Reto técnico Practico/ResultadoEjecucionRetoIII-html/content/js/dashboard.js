/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 94.11764705882354, "KoPercent": 5.882352941176471};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.19230769230769232, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "T9_Logout"], "isController": true}, {"data": [0.0, 500, 1500, "Tx_07_DireccionDeEntrega"], "isController": false}, {"data": [0.0, 500, 1500, "Tx_10_FormaDePago"], "isController": false}, {"data": [0.5, 500, 1500, "Tx_01_Inicio"], "isController": false}, {"data": [0.0, 500, 1500, "T8_ConfirmacionDeOrden"], "isController": true}, {"data": [0.0, 500, 1500, "Tx_15_LogoutDos"], "isController": false}, {"data": [0.0, 500, 1500, "T2_Carrito"], "isController": true}, {"data": [0.0, 500, 1500, "T4_DireccionEntrega"], "isController": true}, {"data": [0.5, 500, 1500, "Tx_03_DetalleProducto"], "isController": false}, {"data": [0.5, 500, 1500, "T3_FormularioUsuarios"], "isController": true}, {"data": [0.0, 500, 1500, "Tx_04_MasDetalles"], "isController": false}, {"data": [0.5, 500, 1500, "Tx_06_FormularioUsuarios"], "isController": false}, {"data": [0.0, 500, 1500, "Tx_13_ConfirmaciónOrdenEnviada"], "isController": false}, {"data": [0.5, 500, 1500, "Tx_17_Logoutcuatro"], "isController": false}, {"data": [0.0, 500, 1500, "T6_PasarelaDePagos"], "isController": true}, {"data": [0.5, 500, 1500, "T1_Inicio"], "isController": true}, {"data": [0.0, 500, 1500, "Tx_05_Autenticacion"], "isController": false}, {"data": [0.5, 500, 1500, "Tx_11_ConfirmacionDePago"], "isController": false}, {"data": [0.0, 500, 1500, "Tx_12_ConfirmaciónDeOrden"], "isController": false}, {"data": [0.5, 500, 1500, "Tx_16_LogoutTres"], "isController": false}, {"data": [0.5, 500, 1500, "Tx_02_Carrito"], "isController": false}, {"data": [0.0, 500, 1500, "Tx_08_DirecciondeEntrega"], "isController": false}, {"data": [0.0, 500, 1500, "T5_TermionsDeServicio"], "isController": true}, {"data": [0.0, 500, 1500, "Tx_09_TerminosDeServicio"], "isController": false}, {"data": [0.0, 500, 1500, "Tx_14_LogoutUno"], "isController": false}, {"data": [0.5, 500, 1500, "T7_ConfirmacionDePago"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 17, 1, 5.882352941176471, 1643.8235294117646, 724, 3823, 2549.3999999999987, 3823.0, 3823.0, 0.6077723356333345, 21.453232253941582, 0.0], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["T9_Logout", 1, 1, 100.0, 8020.0, 8020, 8020, 8020.0, 8020.0, 8020.0, 0.12468827930174563, 17.43358887936409, 0.0], "isController": true}, {"data": ["Tx_07_DireccionDeEntrega", 1, 0, 0.0, 1786.0, 1786, 1786, 1786.0, 1786.0, 1786.0, 0.5599104143337066, 28.839213850783874, 0.0], "isController": false}, {"data": ["Tx_10_FormaDePago", 1, 0, 0.0, 1528.0, 1528, 1528, 1528.0, 1528.0, 1528.0, 0.6544502617801048, 24.42748384325916, 0.0], "isController": false}, {"data": ["Tx_01_Inicio", 1, 0, 0.0, 1405.0, 1405, 1405, 1405.0, 1405.0, 1405.0, 0.7117437722419929, 57.19458963523132, 0.0], "isController": false}, {"data": ["T8_ConfirmacionDeOrden", 1, 0, 0.0, 3362.0, 3362, 3362, 3362.0, 3362.0, 3362.0, 0.29744199881023203, 22.104820419393217, 0.0], "isController": true}, {"data": ["Tx_15_LogoutDos", 1, 0, 0.0, 1503.0, 1503, 1503, 1503.0, 1503.0, 1503.0, 0.6653359946773121, 23.24517631403859, 0.0], "isController": false}, {"data": ["T2_Carrito", 1, 0, 0.0, 5928.0, 5928, 5928, 5928.0, 5928.0, 5928.0, 0.16869095816464236, 18.44134826248313, 0.0], "isController": true}, {"data": ["T4_DireccionEntrega", 1, 0, 0.0, 3556.0, 3556, 3556, 3556.0, 3556.0, 3556.0, 0.281214848143982, 24.98830102291901, 0.0], "isController": true}, {"data": ["Tx_03_DetalleProducto", 1, 0, 0.0, 1195.0, 1195, 1195, 1195.0, 1195.0, 1195.0, 0.8368200836820083, 28.835152981171547, 0.0], "isController": false}, {"data": ["T3_FormularioUsuarios", 1, 0, 0.0, 1271.0, 1271, 1271, 1271.0, 1271.0, 1271.0, 0.7867820613690008, 2.684586447678993, 0.0], "isController": true}, {"data": ["Tx_04_MasDetalles", 1, 0, 0.0, 2231.0, 2231, 2231, 2231.0, 2231.0, 2231.0, 0.44822949350067237, 16.730253389735545, 0.0], "isController": false}, {"data": ["Tx_06_FormularioUsuarios", 1, 0, 0.0, 1271.0, 1271, 1271, 1271.0, 1271.0, 1271.0, 0.7867820613690008, 2.684586447678993, 0.0], "isController": false}, {"data": ["Tx_13_ConfirmaciónOrdenEnviada", 1, 0, 0.0, 1689.0, 1689, 1689, 1689.0, 1689.0, 1689.0, 0.5920663114268797, 21.73357478537596, 0.0], "isController": false}, {"data": ["Tx_17_Logoutcuatro", 1, 0, 0.0, 1416.0, 1416, 1416, 1416.0, 1416.0, 1416.0, 0.7062146892655368, 24.266474664548024, 0.0], "isController": false}, {"data": ["T6_PasarelaDePagos", 1, 0, 0.0, 1528.0, 1528, 1528, 1528.0, 1528.0, 1528.0, 0.6544502617801048, 24.42748384325916, 0.0], "isController": true}, {"data": ["T1_Inicio", 1, 0, 0.0, 1405.0, 1405, 1405, 1405.0, 1405.0, 1405.0, 0.7117437722419929, 57.19458963523132, 0.0], "isController": true}, {"data": ["Tx_05_Autenticacion", 1, 0, 0.0, 1778.0, 1778, 1778, 1778.0, 1778.0, 1778.0, 0.562429696287964, 20.365557332677167, 0.0], "isController": false}, {"data": ["Tx_11_ConfirmacionDePago", 1, 0, 0.0, 869.0, 869, 869, 869.0, 869.0, 869.0, 1.1507479861910241, 33.726805235903335, 0.0], "isController": false}, {"data": ["Tx_12_ConfirmaciónDeOrden", 1, 0, 0.0, 1673.0, 1673, 1673, 1673.0, 1673.0, 1673.0, 0.5977286312014345, 22.479616519725045, 0.0], "isController": false}, {"data": ["Tx_16_LogoutTres", 1, 0, 0.0, 1278.0, 1278, 1278, 1278.0, 1278.0, 1278.0, 0.7824726134585289, 27.09922730829421, 0.0], "isController": false}, {"data": ["Tx_02_Carrito", 1, 0, 0.0, 724.0, 724, 724, 724.0, 724.0, 724.0, 1.3812154696132597, 1.8330779523480663, 0.0], "isController": false}, {"data": ["Tx_08_DirecciondeEntrega", 1, 0, 0.0, 1770.0, 1770, 1770, 1770.0, 1770.0, 1770.0, 0.5649717514124294, 21.10257768361582, 0.0], "isController": false}, {"data": ["T5_TermionsDeServicio", 1, 0, 0.0, 2006.0, 2006, 2006, 2006.0, 2006.0, 2006.0, 0.4985044865403788, 18.619921485543372, 0.0], "isController": true}, {"data": ["Tx_09_TerminosDeServicio", 1, 0, 0.0, 2006.0, 2006, 2006, 2006.0, 2006.0, 2006.0, 0.4985044865403788, 18.619921485543372, 0.0], "isController": false}, {"data": ["Tx_14_LogoutUno", 1, 1, 100.0, 3823.0, 3823, 3823, 3823.0, 3823.0, 3823.0, 0.2615746795710175, 9.386801513863459, 0.0], "isController": false}, {"data": ["T7_ConfirmacionDePago", 1, 0, 0.0, 869.0, 869, 869, 869.0, 869.0, 869.0, 1.1507479861910241, 33.726805235903335, 0.0], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 3,823 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 3,000 milisegundos.", 1, 100.0, 5.882352941176471], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 17, 1, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 3,823 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 3,000 milisegundos.", 1, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Tx_14_LogoutUno", 1, 1, "La operaci&oacute;n dur&oacute; demasiado: tard&oacute; 3,823 milisegundos, cuando no deber&iacute;a haber tardado m&aacute;s de 3,000 milisegundos.", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
